# JM Basketball Vercel Package

This is a deploy-ready Next.js package for jmbasketball.com.

## Deploy on Vercel

1. Go to Vercel and create a new project.
2. Upload this folder or drag-and-drop the ZIP into Vercel.
3. Let Vercel install dependencies and deploy.
4. Add `jmbasketball.com` in Project Settings > Domains.
5. Copy the DNS records Vercel gives you into your domain registrar.

## Run locally

```bash
npm install
npm run dev
```

## Notes

- The site is self-contained and does not rely on local image files.
- College logos and player photos are represented with text badges/initials for reliable deployment.
